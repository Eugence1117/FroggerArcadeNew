import "./style.css";
import { interval, fromEvent, merge, BehaviorSubject } from "rxjs";
import { map, filter, mergeMap, takeUntil, take } from "rxjs/operators";
import { Frog, Ground, River, SafeZone, Terrain, Game, MovingObject, Position, Truck, Car, Log, Wall, Slot} from "./models";
import { Direction } from "./enums";
import * as Constant from "./constant";


export let game:Game;

function main() {
  /**
   * Inside this function you will use the classes and functions from rx.js
   * to add visuals to the svg element in pong.html, animate them, and make them interactive.
   *
   * Study and complete the tasks in observable examples first to get ideas.
   *
   * Course Notes showing Asteroids in FRP: https://tgdwyer.github.io/asteroids/
   *
   * You will be marked on your functional programming style
   * as well as the functionality that you implement.
   *
   * Document your code!
   */

  /**
   * This is the view for your game to add and update your game elements.
   */
  const svg = document.querySelector("#svgCanvas") as SVGElement & HTMLElement;
  svg.style.width = Constant.MAP_SIZE_ROW.toString();
  svg.style.height = Constant.MAP_SIZE_COL.toString();
   // our game has the following view element types:
   type ViewType = 'frog' | 'logs' | 'cars'

   const terrains = initMapTerrain(svg);
   const movingObjs = initMovingObjects(svg);
   game = new Game(terrains,movingObjs);
   initFrog(svg);
  // creating elements on the canvas
    
  // create the water
//   const water = document.createElementNS(svg.namespaceURI, "rect");
//   Object.entries({
//     x: 0,
//     y: 0,
//     width: 600,
//     height: 300,
//     fill: "#95B3D7",
//   }).forEach(([key, val]) => water.setAttribute(key, String(val)));
//   svg.appendChild(water);

  
//   // create the ground
//   const ground1 = document.createElementNS(svg.namespaceURI, "rect");
//   Object.entries({
//     x: 0,
//     y: 480,
//     width: 600,
//     height: 55,
//     fill: "#654321",
//   }).forEach(([key, val]) => ground1.setAttribute(key, String(val)));
//   svg.appendChild(ground1);


// const ground2 = document.createElementNS(svg.namespaceURI, "rect");
//   Object.entries({
//     x: 0,
//     y: 280,
//     width: 600,
//     height: 55,
//     fill: "#654321",
//   }).forEach(([key, val]) => ground2.setAttribute(key, String(val)));
//   svg.appendChild(ground2);


// // create safe part
// const safeGround1 = document.createElementNS(svg.namespaceURI, "rect");
//   Object.entries({
//     x: 0,
//     y: 0,
//     width: 600,
//     height: 10,
//     fill: "#228B22",
//   }).forEach(([key, val]) => safeGround1.setAttribute(key, String(val)));
//   svg.appendChild(safeGround1);

// // create 5 safe spaces for frog
// const safe1 = document.createElementNS(svg.namespaceURI, "rect");
// Object.entries({
//   x: 0,
//   y: 0,
//   width: 60,
//   height: 55,
//   fill: "#228B22",
// }).forEach(([key, val]) => safe1.setAttribute(key, String(val)));
// svg.appendChild(safe1);

// const safe2 = document.createElementNS(svg.namespaceURI, "rect");
// Object.entries({
//   x: 130,
//   y: 0,
//   width: 60,
//   height: 55,
//   fill: "#228B22",
// }).forEach(([key, val]) => safe2.setAttribute(key, String(val)));
// svg.appendChild(safe2);

// const safe3 = document.createElementNS(svg.namespaceURI, "rect");
// Object.entries({
//   x: 265,
//   y: 0,
//   width: 60,
//   height: 55,
//   fill: "#228B22",
// }).forEach(([key, val]) => safe3.setAttribute(key, String(val)));
// svg.appendChild(safe3);

// const safe4 = document.createElementNS(svg.namespaceURI, "rect");
// Object.entries({
//   x: 400,
//   y: 0,
//   width: 60,
//   height: 55,
//   fill: "#228B22",
// }).forEach(([key, val]) => safe4.setAttribute(key, String(val)));
// svg.appendChild(safe4);

// const safe5 = document.createElementNS(svg.namespaceURI, "rect");
// Object.entries({
//   x: 540,
//   y: 0,
//   width: 60,
//   height: 55,
//   fill: "#228B22",
// }).forEach(([key, val]) => safe5.setAttribute(key, String(val)));
// svg.appendChild(safe5);


 
// This function allows the frog to move across the ground and water

function keyboardControl() {
 
  // create the frog
  // svg.appendChild(frog);
  
  // keyboard controls for frog
  const key$ = fromEvent<KeyboardEvent>(document,"keydown"); 

  const moveLeft = key$.pipe(
    // take only left key
    filter(({key}) => key === 'ArrowLeft'),
    filter(({repeat}) => !repeat),
    // check for hold down button 
    // mergeMap(d => interval(10).pipe(
    //   takeUntil(fromEvent<KeyboardEvent>(document, 'keyup').pipe(
    //     filter(({code}) => code === d.code)
    //   )),
    //   map(_=>d)
    // )),
    map(_=> ({
      x: -Constant.BLOCK_SIZE,
      y: 0
    }))
    );

  const moveRight = key$.pipe(
    // take only left key
    filter(({key}) => key === 'ArrowRight'),
    filter(({repeat}) => !repeat),
    // check for hold down button 
    // mergeMap(d => interval(10).pipe(
    //   takeUntil(fromEvent<KeyboardEvent>(document, 'keyup').pipe(
    //     filter(({code}) => code === d.code)
    //   )),
    //   map(_=>d)
    // )),
    map(_=> {    
      return ({
        x: Constant.BLOCK_SIZE,
        y: 0
      })
    })    
    );

  const moveUp = key$.pipe(
    // take only left key
    filter(({key}) => key === 'ArrowUp'),
    filter(({repeat}) => !repeat),
    // check for hold down button 
    // mergeMap(d => interval(10).pipe(
    //   takeUntil(fromEvent<KeyboardEvent>(document, 'keyup').pipe(
    //     filter(({code}) => code === d.code)
    //   )),
    //   map(_=>d)
    // )),
    map(_=> ({
      x: 0,
      y: -Constant.BLOCK_SIZE,
    }))
    );

  const moveDown = key$.pipe(
    // take only left key
    filter(({key}) => key === 'ArrowDown'),
    filter(({repeat}) => !repeat),
    // check for hold down button 
    // mergeMap(d => interval(10).pipe(
    //   takeUntil(fromEvent<KeyboardEvent>(document, 'keyup').pipe(
    //     filter(({code}) => code === d.code)
    //   )),
    //   map(_=>d)
    // )),
    map(_=> ({
      x: 0,
      y: Constant.BLOCK_SIZE,
    }))
    );

  merge(moveLeft,moveRight,moveUp,moveDown).
    subscribe(({x,y}) => {          
      game.frog.x += x;      
      game.frog.y += y; 
      game.frog.updatePosition()          
      //If no collision with object only check terrain
      if(!checkCollideObject(game.frog,movingObjs)){
        checkCollideTerrain(game.frog,terrains);           
      }          
    });  

  
  }

function checkCollideObject(frog:Frog,movingObjects:Array<Array<MovingObject>>):boolean{
  const currentRow = frog.y / Constant.BLOCK_SIZE;
  const rowObjects = movingObjects[currentRow];

  let collidedObject = null;
  frog.ride = undefined;
  for(let item of rowObjects){
    if(item.isFrogHere(new Position(frog.x,frog.y))){
      collidedObject = item;
      break;
    }
  }
  if(collidedObject){
    if(collidedObject.dieOnColide()){
      game.announceDead();
    }
    else{
      if(collidedObject instanceof Log){
        frog.ride = collidedObject;
      }
      else if(collidedObject instanceof Slot){
        game.award(game.lives * 10);
        frog.reset()
        frog.updatePosition();
      }
    }
  }

  return collidedObject != null
}

function checkCollideTerrain(frog:Frog,terrains:Array<Terrain>){
  const currentRow = frog.y / Constant.BLOCK_SIZE;
  console.log("Is Walkable",terrains[currentRow].isWalkable());
  if(!terrains[currentRow].isWalkable()){
    game.announceDead();
  }
}
  
  /**
 * animates an SVG rectangle, passing a continuation to the built-in HTML5 setInterval function.
 * a rectangle smoothly moves to the right for 1 second.
 */


// function animatedLogTimer() {
//     // create the log
//   const log1 = document.createElementNS(svg.namespaceURI, "rect");
//   Object.entries({
//     x: 0,
//     y: 180,
//     width: 80,
//     height: 40,
//     fill: "#966F33",
//   }).forEach(([key, val]) => log1.setAttribute(key, String(val)));
//   svg.appendChild(log1);

//   const animate = setInterval(
//     () => log1.setAttribute("x", String(1 + Number(log1.getAttribute("x")))),
//     10
//   );
//   const timer = setInterval(() => {
//     clearInterval(animate);
//     clearInterval(timer);
//   }, 1000);

//   // create the log2
//   const log2 = document.createElementNS(svg.namespaceURI, "rect");
//   Object.entries({
//     x: 10,
//     y: 200,
//     width: 80,
//     height: 10,
//     fill: "#966F33",
//   }).forEach(([key, val]) => log2.setAttribute(key, String(val)));
//   svg.appendChild(log2);

//   const animate1 = setInterval(
//     () => log2.setAttribute("x", String(2 + Number(log2.getAttribute("x")))),
//     10
//   );
//   const timer1 = setInterval(() => {
//     clearInterval(animate1);
//     clearInterval(timer1);
//   }, 1000);

//     // create the log3
// const log3 = document.createElementNS(svg.namespaceURI, "rect");
// Object.entries({
//   x: 0,
//   y: 220,
//   width: 150,
//   height: 10,
//   fill: "#966F33",
// }).forEach(([key, val]) => log3.setAttribute(key, String(val)));
// svg.appendChild(log3);

// const animate3 = setInterval(
//   () => log3.setAttribute("x", String(3 + Number(log3.getAttribute("x")))),
//   10
// );
// const timer3 = setInterval(() => {
//   clearInterval(animate3);
//   clearInterval(timer3);
// }, 1000);

    
// }

// /**
//  * Demonstrates the interval method
//  * You want to choose an interval so the rectangle animates smoothly
//  * It terminates after 1 second (1000 milliseconds)
//  */
//  function animatedLogs() {

//   // create the log
//   const log1 = document.createElementNS(svg.namespaceURI, "rect");
//   Object.entries({
//     x: 0,
//     y: 180,
//     width: 100,
//     height: 40,
//     fill: "#966F33",
//   }).forEach(([key, val]) => log1.setAttribute(key, String(val)));
//   svg.appendChild(log1);
  
//   const movingInterval = interval(10).pipe(take(100))
//   movingInterval.subscribe(() => log1.setAttribute("x", String(1 + Number(log1.getAttribute("x")))))

//   // log 2
//   const log2 = document.createElementNS(svg.namespaceURI, "rect");
//   Object.entries({
//     x: 0,
//     y: 200,
//     width: 80,
//     height: 10,
//     fill: "#966F33",
//   }).forEach(([key, val]) => log2.setAttribute(key, String(val)));
//   svg.appendChild(log2);
  
//   const movingInterval1 = interval(10).pipe(take(100))
//   movingInterval1.subscribe(() => log2.setAttribute("x", String(2 + Number(log2.getAttribute("x")))))


//   // log 3
//   const log3 = document.createElementNS(svg.namespaceURI, "rect");
//   Object.entries({
//     x: 0,
//     y: 120,
//     width: 120,
//     height: 10,
//     fill: "#966F33",
//   }).forEach(([key, val]) => log3.setAttribute(key, String(val)));
//   svg.appendChild(log3);
  
//   const movingInterval2 = interval(10).pipe(take(100))
//   movingInterval2.subscribe(() => log3.setAttribute("x", String(3 + Number(log3.getAttribute("x")))))
// }

//  /**
//  * animates an SVG rectangle, passing a continuation to the built-in HTML5 setInterval function.
//  * a rectangle smoothly moves to the right for 1 second.
//  */
//   function animatedCarTimer() {
//     // create the car
//   const car1 = document.createElementNS(svg.namespaceURI, "rect");
//   Object.entries({
//     x: 0,
//     y: 350,
//     width: 60,
//     height: 30,
//     fill: "#A020F0",
//   }).forEach(([key, val]) => car1.setAttribute(key, String(val)));
//   svg.appendChild(car1);

//   const animate = setInterval(
//     () => car1.setAttribute("x", String(1 + Number(car1.getAttribute("x")))),
//     10
//   );
//   const timer = setInterval(() => {
//     clearInterval(animate);
//     clearInterval(timer);
//   }, 10);

  
// }

// /**
//  * Demonstrates the interval method
//  * You want to choose an interval so the rectangle animates smoothly
//  * It terminates after 1 second (1000 milliseconds)
//  */
//  function animatedCars() {

//   // create the cars
//   const car1 = document.createElementNS(svg.namespaceURI, "rect");
//   Object.entries({
//     x: 0,
//     y: 350,
//     width: 60,
//     height: 30,
//     fill: "#A020F0",
//   }).forEach(([key, val]) => car1.setAttribute(key, String(val)));
//   svg.appendChild(car1);
  
//   const movingInterval = interval(10).pipe(take(100))
//   movingInterval.subscribe(() => car1.setAttribute("x", String(1 + Number(car1.getAttribute("x")))))

  
// }

keyboardControl();
// animatedLogTimer();
// animatedLogs();
// animatedCarTimer();
// animatedCars();

}

function initMapTerrain(svg:SVGElement):Array<Terrain>{
  const map:Array<Terrain> = [
    new SafeZone(0,Constant.MAP_SIZE_ROW,0 * Constant.BLOCK_SIZE),
    new River(0,Constant.MAP_SIZE_ROW,1 * Constant.BLOCK_SIZE),
    new River(0,Constant.MAP_SIZE_ROW,2 * Constant.BLOCK_SIZE),
    new River(0,Constant.MAP_SIZE_ROW,3 * Constant.BLOCK_SIZE),
    new River(0,Constant.MAP_SIZE_ROW,4 * Constant.BLOCK_SIZE),
    new SafeZone(0,Constant.MAP_SIZE_ROW,5 * Constant.BLOCK_SIZE),
    new Ground(0,Constant.MAP_SIZE_ROW,6 * Constant.BLOCK_SIZE),
    new Ground(0,Constant.MAP_SIZE_ROW,7 * Constant.BLOCK_SIZE),
    new Ground(0,Constant.MAP_SIZE_ROW,8 * Constant.BLOCK_SIZE),
    new Ground(0,Constant.MAP_SIZE_ROW,9 * Constant.BLOCK_SIZE),
    new SafeZone(0,Constant.MAP_SIZE_ROW,10 * Constant.BLOCK_SIZE),    
  ]
  
  const elements = map.map((tile) => tile.renderElement(svg));  
  return map;
}

function initMovingObjects(svg:SVGElement):Array<Array<MovingObject>>{
  const movingObjs =  [
    [
      new Wall(0,0),
      new Slot(1,0),
      new Wall(2,0),
      new Slot(3,0),
      new Wall(4,0),
      new Slot(5,0),
      new Wall(6,0),
      new Slot(7,0),
      new Wall(8,0),
    ],
    [
      new Log(0,1,4,1.5,Direction.Right),
      new Log(6,1,2,1.5,Direction.Right),            
    ],
    [
      new Log(2,2,2,2,Direction.Left),
      new Log(6,2,3,2,Direction.Left), 
      new Log(9,2,2,2,Direction.Left),       
    ],
    [
      new Log(1,3,2,2.5,Direction.Right),
      new Log(5,3,2,2.5,Direction.Right), 
      new Log(8,3,2,2.5,Direction.Right),        
    ],
    [
      new Log(2,4,3,2,Direction.Left),       
      new Log(6,4,2,2,Direction.Left),      
      new Log(9,4,2,2,Direction.Left),              
    ],
    [],
    [
      new Truck(0,6,2,Direction.Left),
      new Truck(4,6,2,Direction.Left),
      new Truck(7,6,2,Direction.Left),      
    ],
    [
      new Car(0,7,3,Direction.Right),
      new Car(3,7,3,Direction.Right),
      new Truck(6,7,3,Direction.Right),     
      new Car(9,7,3,Direction.Right),      
    ],
    [
      new Car(2,8,2.5,Direction.Right),
      new Car(5,8,2.5,Direction.Right),      
      new Car(10,8,2.5,Direction.Right), 
    ],
    [
      new Car(0,9,2,Direction.Right),
      new Car(4,9,2,Direction.Right),      
      new Car(5,9,2,Direction.Right), 
      new Car(9,9,2,Direction.Right), 
    ],
    []    
  ];
  movingObjs.forEach(row => {
    row.forEach((obj) => {
      obj.renderElement(svg);
    })
  })

  return movingObjs
}

function initFrog(svg:SVGElement):void{
  game.frog.renderElement(svg);
}

// The following simply runs your main function on window load.  Make sure to leave it in place.
if (typeof window !== "undefined") {
  window.onload = () => {
    document.getElementById("status")!!.style.width = Constant.MAP_SIZE_ROW.toString();    
    main();
    game.listener.subscribe({
      next:(game) => {
        document.querySelector("#live > span")!!.innerHTML = game.lives.toString();
        document.querySelector("#score > span")!!.innerHTML = game.score.toString();
      }
    })
  };
}
