export enum Direction{
    Left = 1,
    Right = 2
}

export enum Difficulty{
    Easy = 0,
    Normal = 1,
    Hard = 2,
    Extreme = 3,        
}
