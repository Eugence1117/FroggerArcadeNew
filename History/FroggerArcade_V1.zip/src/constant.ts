export const FROG_SIZE = 25;
export const BLOCK_SIZE = 50;
export const MAP_TOTAL_COLUMN = 11;
export const MAP_TOTAL_ROW = 9;


export const MAP_SIZE_COL = MAP_TOTAL_COLUMN * BLOCK_SIZE;
export const MAP_SIZE_ROW = MAP_TOTAL_ROW * BLOCK_SIZE;

