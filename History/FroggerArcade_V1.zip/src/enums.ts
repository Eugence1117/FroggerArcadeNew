export enum Direction{
    Left = 1,
    Right = 2
}

export enum Difficulty{
    Easy = 5,
    Normal = 4,
    Hard = 3,
    Extreme = 2,        
}
